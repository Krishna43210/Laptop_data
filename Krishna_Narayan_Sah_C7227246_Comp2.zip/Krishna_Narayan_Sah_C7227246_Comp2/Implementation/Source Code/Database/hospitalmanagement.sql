INSERT INTO `beds` (`id`, `floor_id`, `bed_category_id`, `name`, `limit`, `cost`, `slug`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Cabin', 20, 500, 'cabin', 1, '2021-10-21 08:21:58', '2021-10-21 08:21:58'),
(2, 1, 2, 'cabin', 10, 450, 'cabin', 1, '2021-10-21 08:22:53', '2021-10-21 08:22:53');


INSERT INTO `bed_categories` (`id`, `floor_id`, `name`, `details`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, '1st class', 'The standard Lorem Ipsum passage, used since the 1500s\r\n\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 1, '2021-10-21 08:21:29', '2021-10-21 08:21:29'),
(2, 1, '2nd class', 'The standard Lorem Ipsum passage, used since the 1500s\r\n\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 1, '2021-10-21 08:21:41', '2021-10-21 08:21:41'),
(3, 1, 'icu', 'The standard Lorem Ipsum passage, used since the 1500s\r\n\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 1, '2021-10-21 08:24:25', '2021-10-21 08:24:25'),
(4, 1, 'ccu', 'The standard Lorem Ipsum passage, used since the 1500s\r\n\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 1, '2021-10-21 08:24:36', '2021-10-21 08:24:36');

INSERT INTO `departments` (`id`, `name`, `description`, `photo`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Eye section', 'Eye Section', NULL, 1, '2022-01-11 08:06:07', '2022-01-11 08:06:07');

INSERT INTO `doctors` (`id`, `department_id`, `user_id`, `name`, `email`, `phone`, `photo`, `speciality`, `creator`, `slug`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 5, 'Elza Hermann', 'dibbert.carlie@example.net', '+1 (480) 401-5978', 'https://via.placeholder.com/900x300.png/00aa88?text=est', 't0kWR63XOQR', NULL, 'ut-aliquid-aliquid-vel-qui-quam', 0, '2021-10-26 10:46:55', '2021-10-26 10:46:55'),
(2, 1, 3, 'Chasity Waters IV', 'larissa79@example.org', '+17725780406', 'https://via.placeholder.com/900x300.png/0055cc?text=provident', 'zu31jp27urp', NULL, 'expedita-quod-repudiandae-et-quos-voluptas-aut', 1, '2021-10-26 10:46:55', '2021-10-26 10:46:55'),
(3, 5, 1, 'Garnet Spinka', 'ebert.ryley@example.net', '+1 (765) 814-6002', 'https://via.placeholder.com/900x300.png/002200?text=blanditiis', 'mr9XHsVo30z', NULL, 'blanditiis-est-consequatur-ut-in-ea-vel-quibusdam', 0, '2021-10-26 10:46:55', '2021-10-26 10:46:55'),
(4, 4, 4, 'Rosario Gaylord', 'jamison.bashirian@example.com', '+13862868313', 'https://via.placeholder.com/900x300.png/0099cc?text=sed', '9AoBTa60NeP', NULL, 'iusto-quia-necessitatibus-asperiores-aut-qui', 0, '2021-10-26 10:46:55', '2021-10-26 10:46:55'),
(5, 2, 4, 'Ressie Langosh', 'strosin.lorine@example.com', '1-737-333-2510', 'https://via.placeholder.com/900x300.png/00dd55?text=et', 'c5fpOZcPKT7', NULL, 'beatae-voluptas-quibusdam-magnam-molestiae-dolorem-dignissimos-assumenda', 1, '2021-10-26 10:46:55', '2021-10-26 10:46:55'),
(6, 1, 5, 'Justen Senger', 'swift.ransom@example.net', '(870) 575-6309', 'https://via.placeholder.com/900x300.png/005599?text=ut', 'i17mSTInAa6', NULL, 'quaerat-eius-consequuntur-quia-voluptatem-distinctio-nulla-sit-et', 1, '2021-10-26 10:46:55', '2021-10-26 10:46:55'),
(7, 1, 1, 'Miss Sadye Mitchell', 'lavada91@example.com', '(662) 673-8635', 'https://via.placeholder.com/900x300.png/00eecc?text=officia', 'HSpCvbtOyeP', NULL, 'praesentium-aut-voluptatum-placeat-numquam', 1, '2021-10-26 10:46:55', '2021-10-26 10:46:55'),
(8, 2, 5, 'Soledad Feeney DDS', 'diamond.harber@example.net', '1-347-990-7554', 'https://via.placeholder.com/900x300.png/002255?text=architecto', 'kmWP3myOWGx', NULL, 'dicta-labore-vitae-consequatur-repellat-ut-omnis', 0, '2021-10-26 10:46:55', '2021-10-26 10:46:55'),
(9, 3, 5, 'Rosalind Lueilwitz', 'dbayer@example.net', '1-773-922-1752', 'https://via.placeholder.com/900x300.png/006688?text=aspernatur', 'Q4LOt8PJZKb', NULL, 'ea-nesciunt-eligendi-non-aliquid', 1, '2021-10-26 10:46:55', '2021-10-26 10:46:55');

INSERT INTO `finances` (`id`, `patient_id`, `patient_admission_id`, `name`, `service_name`, `service_cost`, `discharge_date`, `total_day`, `total_bill`, `note`, `payment_status`, `created_at`, `updated_at`) VALUES
(5, NULL, NULL, 'sajid', 'X-ray', 700, NULL, 3, 2100, '', 0, '2021-12-25 11:14:30', '2021-12-25 11:14:30'),
(6, NULL, NULL, 'sajid', 'ultrasnow', 7800, NULL, 2, 15600, '', 0, '2021-12-25 12:04:54', '2021-12-25 12:04:54'),
(7, NULL, NULL, 'sajid', 'x-ray', 700, NULL, 2, 1400, '', 0, '2021-12-31 07:50:04', '2021-12-31 07:50:13');


INSERT INTO `floors` (`id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, '1st Floor', 'The standard Lorem Ipsum passage, used since the 1500s\r\n\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 1, '2021-10-21 08:21:16', '2021-10-21 08:21:16');

INSERT INTO `in_patients` (`id`, `admission_id`, `name`, `sex`, `age`, `phone`, `guardian_name`, `guardian_phone`, `blood_group`, `symptoms`, `condition`, `note`, `department_id`, `doctor_id`, `floor_id`, `bed_category_id`, `bed_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'P-IL6OH', 'sajid', 'male', '54', '01987522979', 'sahab uddin', '01987522979', 'A+', 'no symptomps', 'no symptomps', 'no symptomps', 1, 2, 1, 1, 1, 1, '2022-01-12 12:03:23', '2022-01-12 12:03:23');


INSERT INTO `roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Super admin', 'super-admin', '2021-10-26 16:44:59', NULL);

INSERT INTO `role_user` (`role_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL);

INSERT INTO `users` (`id`, `name`, `photo`, `email`, `phone`, `status`, `email_verified_at`, `password`, `slug`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'images/default-user-photo.jpg', 'superadmin@gmail.com', 198756545, 1, NULL, '$2y$10$5OBlYTB0yHJCsknakKbdTuUw0TXwHTa9D6atEjM4NteAUzUS.5IiG', NULL, NULL, '2021-10-21 08:20:50', '2021-10-21 08:20:50');


INSERT INTO `user_roles` (`id`, `name`, `serial`, `creator`, `slug`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 1, NULL, 'super-admin', NULL, '2021-09-30 10:51:09', '2021-09-30 10:51:09'),
(2, 'Admin', 2, NULL, 'admin', NULL, '2021-09-30 10:51:09', '2021-09-30 10:51:09'),
(3, 'Doctor', 3, NULL, 'doctor', NULL, '2021-09-30 10:51:09', '2021-09-30 10:51:09'),
(4, 'Stuff', 4, NULL, 'stuff', NULL, '2021-09-30 10:51:09', '2021-09-30 10:51:09'),
(5, 'Patient', 5, NULL, 'patient', NULL, '2021-09-30 10:51:09', '2021-09-30 10:51:09');

