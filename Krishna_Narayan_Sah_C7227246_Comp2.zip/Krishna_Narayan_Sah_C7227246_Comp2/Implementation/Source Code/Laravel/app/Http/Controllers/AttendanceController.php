<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Attendance;
use App\Models\AttendanceSchedule;
use App\Models\Role;
use Carbon\Carbon;

class AttendanceController extends Controller
{

    public function schedule()
    {
        $roles = Role::all();
        $sc =  AttendanceSchedule::all();
        return view('admin.attendance-schedule.schedule', compact('roles','sc'));
    }

    public function scheduleStore()
    {
        AttendanceSchedule::create(request()->all());
        return back();   
    }

    public function store()
    {

        $attendance = request()->all();
        $attendance['date'] = date('Y-m-d');
        $attendance['attendance_id'] = "1";
        Attendance::create($attendance);
        return back();
    }

    public function docList()
    {
        
    }

    public function staffList()
    {
        
    }
}
